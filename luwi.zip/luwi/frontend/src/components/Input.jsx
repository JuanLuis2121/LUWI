
import { useState } from "react";

const icons = {
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M5 21a7 7 0 0 1 14 0Z" />
    </>
  ),
  mail: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="m3 7 9 6 9-6" />
    </>
  ),
  lock: (
    <>
      <rect x="5" y="10" width="14" height="11" rx="2" />
      <path d="M8 10V7a4 4 0 0 1 8 0v3" />
    </>
  ),
};

function Icon({ name }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-[17px] w-[17px] shrink-0 text-[#0877df]"
      fill="currentColor"
      aria-hidden="true"
    >
      {icons[name] || icons.user}
    </svg>
  );
}

export default function Input({
  icon,
  type = "text",
  error,
  className = "",
  ...props
}) {
  const [visible, setVisible] = useState(false);
  const isPassword = type === "password";

  return (
    <div className={`w-full ${className}`}>
      <div
        className={`
          flex h-[49px] items-center gap-3 rounded-full
          border bg-white/85 px-5
          transition-all duration-200
          focus-within:border-[#268cf0]
          focus-within:shadow-[0_0_0_3px_rgba(37,140,240,0.10)]
          ${error ? "border-red-400" : "border-[#d6e3f7]"}
        `}
      >
        {icon && <Icon name={icon} />}

        <input
          type={isPassword && visible ? "text" : type}
          className="w-full min-w-0 bg-transparent text-[14px] text-[#12306e] outline-none placeholder:text-[#91a2bd]"
          {...props}
        />

        {isPassword && (
          <button
            type="button"
            onClick={() => setVisible((v) => !v)}
            aria-label={visible ? "Ocultar contraseña" : "Mostrar contraseña"}
            className="shrink-0 text-[#6683ae] transition hover:text-[#0877df]"
          >
            <svg
              viewBox="0 0 24 24"
              className="h-[17px] w-[17px]"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              {visible ? (
                <>
                  <path d="M3 3l18 18" />
                  <path d="M10.6 6.1A9.7 9.7 0 0 1 12 6c5 0 9 6 9 6a15 15 0 0 1-3.2 3.7M6.6 7.6A15 15 0 0 0 3 12s4 6 9 6a9 9 0 0 0 3.4-.7" />
                </>
              ) : (
                <>
                  <path d="M3 12s4-6 9-6 9 6 9 6-4 6-9 6-9-6-9-6Z" />
                  <circle cx="12" cy="12" r="3" />
                </>
              )}
            </svg>
          </button>
        )}
      </div>

      {error && (
        <p className="mt-1.5 pl-4 text-xs text-red-500">
          {error}
        </p>
      )}
    </div>
  );
}
