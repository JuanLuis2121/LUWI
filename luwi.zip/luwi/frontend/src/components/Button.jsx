
export default function Button({
  children,
  loading = false,
  className = "",
  ...props
}) {
  return (
    <button
      disabled={loading || props.disabled}
      className={`
        flex h-[49px] w-full items-center justify-center gap-2
        rounded-full bg-gradient-to-r
        from-[#0750b5] to-[#079cff]
        px-6 text-[14px] font-bold
        text-white shadow-[0_9px_22px_rgba(0,105,220,0.20)]
        transition-all duration-200
        hover:-translate-y-0.5 hover:brightness-110
        focus:outline-none focus-visible:ring-4
        focus-visible:ring-blue-300/50
        disabled:cursor-not-allowed disabled:opacity-60
        ${className}
      `}
      {...props}
    >
      {loading ? (
        "Cargando..."
      ) : (
        <>
          {children}
          <span aria-hidden="true" className="text-lg leading-none">›</span>
        </>
      )}
    </button>
  );
}
