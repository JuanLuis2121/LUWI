
import { useId } from "react";

export default function Logo({ className = "" }) {
  const id = useId();

  return (
    <div className={`flex flex-col items-start ${className}`}>
      <svg
        viewBox="0 0 280 100"
        className="h-[92px] w-auto"
        xmlns="http://www.w3.org/2000/svg"
        role="img"
        aria-label="LUWI"
      >
        <defs>
          <linearGradient
            id={`${id}-gradient`}
            x1="0"
            y1="0"
            x2="280"
            y2="0"
            gradientUnits="userSpaceOnUse"
          >
            <stop offset="0%" stopColor="#07377F" />
            <stop offset="48%" stopColor="#0755B8" />
            <stop offset="76%" stopColor="#078CF0" />
            <stop offset="100%" stopColor="#00B5EF" />
          </linearGradient>
        </defs>

        <text
          x="4"
          y="68"
          fill={`url(#${id}-gradient)`}
          fontFamily="Arial Rounded MT Bold, Trebuchet MS, Arial, sans-serif"
          fontSize="76"
          fontWeight="900"
          letterSpacing="-5"
        >
          LUWI
        </text>

        <text
          x="8"
          y="91"
          fill="#07377F"
          fontFamily="Arial, sans-serif"
          fontSize="11"
          fontWeight="500"
        >
          Learn · Upgrade · Work · Improve
        </text>
      </svg>
    </div>
  );
}
