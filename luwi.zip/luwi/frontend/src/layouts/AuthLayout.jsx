
import Logo from "../components/Logo";

export default function AuthLayout({ title, subtitle, children }) {
  return (
    <main className="relative grid min-h-screen place-items-center overflow-hidden bg-[#eaf2ff] px-4 py-5">

      {/* Fondo general */}
      <div className="pointer-events-none absolute -left-40 -top-48 h-[600px] w-[600px] rounded-full bg-[#c6ddff]/70 blur-3xl" />
      <div className="pointer-events-none absolute -right-40 -bottom-48 h-[650px] w-[650px] rounded-full bg-[#9fcaff]/60 blur-3xl" />

      {/* Tarjeta */}
      <section className="relative grid h-[min(650px,calc(100svh-40px))] min-h-[560px] w-full max-w-[1000px] grid-cols-[58%_42%] overflow-hidden rounded-[30px] border-2 border-white/90 bg-white/70 shadow-[0_25px_70px_rgba(30,75,150,0.18)] backdrop-blur-xl">

        {/* Panel izquierdo */}
        <div className="relative flex min-w-0 flex-col overflow-hidden bg-gradient-to-br from-[#e3efff] via-[#b7d8ff] to-[#62baff] px-8 py-7 sm:px-10">

          {/* Decoración */}
          <div className="pointer-events-none absolute -left-40 -top-48 h-[570px] w-[570px] rounded-full bg-white/30" />
          <div className="pointer-events-none absolute -right-48 -top-40 h-[550px] w-[550px] rounded-full border-[65px] border-white/20" />

          {/* Olas inferiores */}
          <div className="pointer-events-none absolute -bottom-[270px] -left-[170px] h-[520px] w-[650px] rounded-[50%] bg-[#0754b8]" />
          <div className="pointer-events-none absolute -bottom-[320px] -left-[65px] h-[450px] w-[550px] rounded-[50%] bg-[#073d91]" />

          {/* Logo y eslogan */}
          <div className="relative z-10">
            <Logo className="items-start" />

            <p className="mt-1 text-[9px] font-medium tracking-wide text-[#31517f]">
              Learn · Upgrade · Work · Improve
            </p>

            <h2 className="mt-7 max-w-[390px] text-[36px] font-bold leading-[1.12] tracking-[-1.2px] text-[#0b367b]">
              Tu camino de
              <span className="block text-[#0788ed]">
                aprendizaje,
              </span>
              en un solo lugar.
            </h2>

            <p className="mt-4 max-w-[300px] text-[15px] leading-relaxed text-[#174b91]">
              Conecta, aprende y sigue tu progreso con LUWI.
            </p>
          </div>

          {/* Ilustración integrada */}
          <div className="pointer-events-none absolute bottom-5 left-1/2 z-10 w-[88%] max-w-[430px] -translate-x-1/2">
            <img
              src="/LUWI-login-illustration.png"
              alt="Laptop con birrete que representa el aprendizaje"
              className="h-auto w-full object-contain drop-shadow-[0_15px_20px_rgba(0,45,110,0.20)] [mask-image:radial-gradient(ellipse_72%_70%_at_50%_50%,black_48%,transparent_100%)]"
            />
          </div>
        </div>

        {/* Panel derecho */}
        <div className="relative z-20 -ml-5 flex min-w-0 flex-col justify-center rounded-l-[48px] bg-white/90 px-8 py-8 shadow-[-12px_0_35px_rgba(255,255,255,0.25)] backdrop-blur-xl sm:px-10">

          <div className="pointer-events-none absolute right-0 top-0 h-64 w-64 rounded-full bg-[#e6f1ff]/70 blur-3xl" />

          <div className="relative z-10 mx-auto w-full max-w-[360px]">

            <header className="mb-7">
              <h1 className="flex flex-wrap items-center gap-2 text-[29px] font-bold leading-tight tracking-[-1px] text-[#0b3275]">
                {title}
                <span aria-hidden="true" className="text-[25px]">👋</span>
              </h1>

              {subtitle && (
                <p className="mt-2 text-[14px] leading-relaxed text-[#7184a9]">
                  {subtitle}
                </p>
              )}
            </header>

            {children}

          </div>
        </div>
      </section>
    </main>
  );
}
