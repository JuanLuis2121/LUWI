
import Logo from "../components/Logo";

export default function AuthLayout({
  title,
  subtitle,
  children,
  footer,
}) {
  return (
    <main className="relative grid min-h-screen place-items-center overflow-hidden bg-[#eaf2ff] px-3 py-6 sm:px-6 lg:px-8">

      {/* FONDO GENERAL */}
      <div className="pointer-events-none absolute -left-56 -top-64 h-[760px] w-[760px] rounded-full bg-[#c6ddff]/80 blur-3xl" />

      <div className="pointer-events-none absolute -right-48 -top-48 h-[700px] w-[700px] rounded-full bg-[#8bbcff]/50 blur-3xl" />

      <div className="pointer-events-none absolute -bottom-80 left-[10%] h-[650px] w-[650px] rounded-full bg-[#a9d2ff]/60 blur-3xl" />

      {/* TARJETA PRINCIPAL */}
      <section className="relative grid w-[min(90vw,1300px)] min-h-[760px] overflow-hidden rounded-[38px] border-[3px] border-white/85 bg-white/60 shadow-[0_30px_90px_rgba(30,75,150,0.20)] backdrop-blur-2xl lg:grid-cols-[60%_40%]">

        {/* PANEL IZQUIERDO */}
        <div className="relative flex min-h-[700px] flex-col overflow-hidden bg-gradient-to-br from-[#dceaff] via-[#b5d7ff] to-[#75bcff] px-8 py-10 sm:px-12 lg:px-[62px] lg:py-12">

          {/* FORMAS ORGÁNICAS */}
          <div className="pointer-events-none absolute -left-[210px] -top-[280px] h-[760px] w-[760px] rounded-full bg-white/35" />

          <div className="pointer-events-none absolute -right-[280px] -top-[300px] h-[780px] w-[780px] rounded-full border-[95px] border-white/25" />

          <div className="pointer-events-none absolute -bottom-[320px] -left-[220px] h-[650px] w-[650px] rounded-full bg-[#0753b7]" />

          <div className="pointer-events-none absolute -bottom-[400px] -left-[100px] h-[600px] w-[600px] rounded-full bg-[#063b91]" />

          <div className="pointer-events-none absolute -bottom-[250px] right-[-230px] h-[600px] w-[600px] rounded-full bg-[#26aaff]/40 blur-2xl" />

          {/* LOGO Y TEXTO */}
          <div className="relative z-10">

            <Logo />

            <h2 className="mt-10 max-w-[550px] text-[38px] font-bold leading-[1.12] tracking-[-1.5px] text-[#0b367b] sm:text-[44px] lg:text-[48px]">
              Tu camino de

              <span className="block bg-gradient-to-r from-[#0784ed] to-[#00a4f5] bg-clip-text text-transparent">
                aprendizaje,
              </span>

              en un solo lugar.
            </h2>

            <p className="mt-6 max-w-[400px] text-[18px] leading-[1.5] text-[#073b83] sm:text-[20px]">
              Conecta, aprende y sigue
              <br />
              tu progreso con LUWI.
            </p>
          </div>

          {/* ILUSTRACIÓN 3D */}
          <div className="relative z-10 mt-auto flex min-h-[320px] flex-1 items-center justify-center py-5">

            <img
              src="/LUWI-login-illustration.png"
              alt="Laptop con birrete que representa el aprendizaje y el progreso"
              className="h-auto w-full max-w-[590px] object-contain mix-blend-multiply drop-shadow-[0_22px_24px_rgba(0,55,130,0.16)]"
            />

          </div>

          {/* FRASE INFERIOR */}
          <div className="relative z-10 mt-auto pt-3 text-[11px] font-semibold tracking-[1.5px] text-white">
            LEARN · UPGRADE · WORK · IMPROVE
          </div>
        </div>

        {/* PANEL DERECHO */}
        <div className="relative flex flex-col justify-center overflow-hidden bg-white/75 px-7 py-12 backdrop-blur-2xl sm:px-12 lg:px-12 xl:px-14">

          {/* LUCES DECORATIVAS */}
          <div className="pointer-events-none absolute -right-40 -top-40 h-[480px] w-[480px] rounded-full bg-[#dceaff]/70 blur-3xl" />

          <div className="pointer-events-none absolute -bottom-40 -left-40 h-[450px] w-[450px] rounded-full bg-[#e5f1ff]/80 blur-3xl" />

          {/* CONTENIDO DEL FORMULARIO */}
          <div className="relative z-10 mx-auto w-full max-w-[500px]">

            <header className="mb-10">

              <h1 className="text-[34px] font-bold leading-tight tracking-[-1.2px] text-[#0b3275] sm:text-[39px]">
                {title}
              </h1>

              {subtitle && (
                <p className="mt-3 text-[17px] leading-relaxed text-[#647da9] sm:text-[19px]">
                  {subtitle}
                </p>
              )}

            </header>

            {/* FORMULARIO ORIGINAL: CONSERVA LA AUTENTICACIÓN */}
            {children}

            {/* PIE DEL FORMULARIO */}
            {footer && (
              <div className="mt-9 border-t border-[#d9e7fc] pt-7 text-center text-sm text-[#65799e]">
                {footer}
              </div>
            )}

          </div>
        </div>
      </section>
    </main>
  );
}
