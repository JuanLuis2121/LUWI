
import { useState } from "react";

const icons = {
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M5 21a7 7 0 0 1 14 0" />
    </>
  ),
  mail: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="m3 7 9 6 9-6" />
    </>
  ),
  lock: (
    <>
      <rect x="5" y="11" width="14" height="9" rx="2" />
      <path d="M8 11V8a4 4 0 0 1 8 0v3" />
    </>
  ),
};

function Icon({ name }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-5 w-5 shrink-0 text-[#1555a5]"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {icons[name] || icons.user}
    </svg>
  );
}

export default function Input({
  icon,
  type = "text",
  error,
  className = "",
  ...props
}) {
  const [visible, setVisible] = useState(false);
  const isPassword = type === "password";

  return (
    <div className={`w-full ${className}`}>
      <div
        className={`
          flex items-center gap-4 rounded-[20px]
          border bg-white/55 px-5 py-[17px]
          backdrop-blur-md transition-all duration-200
          focus-within:border-[#258cf0]
          focus-within:bg-white/85
          focus-within:shadow-[0_0_0_4px_rgba(37,140,240,0.10)]
          ${error
            ? "border-red-400"
            : "border-[#c9dcf8]"
          }
        `}
      >
        {icon && <Icon name={icon} />}

        <input
          type={isPassword && visible ? "text" : type}
          className="w-full bg-transparent text-[15px] text-[#12306e] outline-none placeholder:text-[#8295b8]"
          {...props}
        />

        {isPassword && (
          <button
            type="button"
            onClick={() => setVisible((v) => !v)}
            aria-label={
              visible ? "Ocultar contraseña" : "Mostrar contraseña"
            }
            className="text-[#607ba7] transition hover:text-[#0877df]"
          >
            <svg
              viewBox="0 0 24 24"
              className="h-5 w-5"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              {visible ? (
                <>
                  <path d="M3 3l18 18" />
                  <path d="M10.6 6.1A9.7 9.7 0 0 1 12 6c5 0 9 6 9 6a15 15 0 0 1-3.2 3.7M6.6 7.6A15 15 0 0 0 3 12s4 6 9 6a9 9 0 0 0 3.4-.7" />
                </>
              ) : (
                <>
                  <path d="M3 12s4-6 9-6 9 6 9 6-4 6-9 6-9-6-9-6Z" />
                  <circle cx="12" cy="12" r="3" />
                </>
              )}
            </svg>
          </button>
        )}
      </div>

      {error && (
        <p className="mt-2 pl-2 text-xs text-red-500">
          {error}
        </p>
      )}
    </div>
  );
}
