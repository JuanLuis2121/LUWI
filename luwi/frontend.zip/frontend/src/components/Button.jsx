
export default function Button({
  children,
  loading = false,
  className = "",
  ...props
}) {
  return (
    <button
      disabled={loading || props.disabled}
      className={`
        flex w-full items-center justify-center gap-3
        rounded-full bg-gradient-to-r
        from-[#0645a5] to-[#079cff]
        px-6 py-[17px] text-base font-semibold
        text-white shadow-[0_10px_25px_rgba(0,105,220,0.22)]
        transition-all duration-300
        hover:-translate-y-0.5 hover:brightness-110
        hover:shadow-[0_14px_30px_rgba(0,105,220,0.30)]
        focus:outline-none focus-visible:ring-4
        focus-visible:ring-blue-300/50
        disabled:cursor-not-allowed disabled:opacity-60
        ${className}
      `}
      {...props}
    >
      {loading ? "Cargando..." : children}

      {!loading && (
        <svg
          viewBox="0 0 24 24"
          className="h-5 w-5"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M5 12h14M13 6l6 6-6 6" />
        </svg>
      )}
    </button>
  );
}
